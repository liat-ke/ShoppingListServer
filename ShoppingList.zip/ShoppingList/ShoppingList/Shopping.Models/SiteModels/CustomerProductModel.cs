﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.Models.SiteModels
{
    public class CustomerProductModel
    {
        public int CustomerID { get; set; }
        public int CategoryID { get; set; }
        public string ProductName { get; set; }
        public string CategoryName { get; set; }
        public int CountCategory { get; set; }
        public DateTime? CreatedDate { get; set; }
        public List<InnerCustomerItem> InnerCustomerItems { get; set; }
    }
}

    public class InnerCustomerItem
    {
        public int Quantity { get; set; }
        public string ProductName { get; set; }
    }
