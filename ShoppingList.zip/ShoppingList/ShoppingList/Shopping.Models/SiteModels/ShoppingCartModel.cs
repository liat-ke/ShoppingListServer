﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.Models.SiteModels
{
    public class ShoppingCartModel
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public int CountCategory { get; set; }
        public List<InnerItem> InnerItems { get; set; }
    }
    public class InnerItem
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
    }
}
