﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.Models.SiteModels
{
    public class ShoppingCartItemModel
    {
        public int CustomerID { get; set; }
        public List<ProductModel> Products{ get; set; }
    }
}
