﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Shopping.Models.SiteModels;
using Shopping.Web.Services;
using Shopping.Web.Services.Impl;
using System.Collections.Generic;

namespace Shopping.Web.Controllers
{
    [EnableCors()]
    [ApiController]
    [Route("[controller]")]
    public class ShoppingCartController : ControllerBase
    {
        private readonly IShoppingCartService _shoppingCartService;


        public ShoppingCartController(IShoppingCartService shoppingCartService)
        {
            _shoppingCartService = shoppingCartService;
        }

        [HttpPost]
        [Route("AddItemsToShoppingCart")]
        public IActionResult AddItemsToShoppingCart([FromBody] CustomerProductModel customerProduct)
        {
            List<CustomerProductModel> productAdded = _shoppingCartService.AddItemToCustomerProducts(customerProduct);
            return Ok(productAdded);
        }
    }
}
