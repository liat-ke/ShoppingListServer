﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Shopping.Models.SiteModels;
using Shopping.Web.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Shopping.Web.Controllers
{
    [EnableCors()]
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpPost]
        [Route("AddItemsToShoppingCart")]
        public IActionResult AddItemsToShoppingCart([FromBody] ShoppingCartItemModel shoppingCartItems)
        {
            List<ShoppingCartModel> productAdded = _productService.AddItemsToShoppingCart(shoppingCartItems);
            return Ok(productAdded);
        }
    }
}
