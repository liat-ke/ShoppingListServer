﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Shopping.Models.SiteModels;
using Shopping.Web.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopping.Web.Controllers
{
    [EnableCors()]
    [ApiController]
    [Route("[controller]")]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryService _categoeyService;

        public CategoryController(ICategoryService categoeyService)
        {
            _categoeyService = categoeyService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            List<CategoryModel> categories = _categoeyService.GetEnabledCategoriesModel();

            return Ok(categories);

        }

        [Route("GetProducts")]
        [HttpGet]
        public IActionResult GetProducts(int categoryID)
        {
            List<ProductModel> products = _categoeyService.GetProductsByCategoryID(categoryID);

            return Ok(products);

        }
    }
}
