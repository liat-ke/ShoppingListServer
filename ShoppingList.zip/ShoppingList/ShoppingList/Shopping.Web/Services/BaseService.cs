﻿using Shopping.Data;
using Shopping.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopping.Web.Services
{
    public class BaseService
    {
        protected readonly ShoppingContext _db;

        protected BaseService(ShoppingContext db)
        {
            _db = db;
        }
    }
}
