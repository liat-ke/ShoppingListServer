﻿using Shopping.Data;
using Shopping.Data.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Shopping.Models.SiteModels;
using System.Diagnostics;

namespace Shopping.Web.Services.Impl
{
    public class CategoryService : BaseService, ICategoryService
    {
        public CategoryService(ShoppingContext db) : base(db)
        {

        }

        public List<CategoryModel> GetEnabledCategoriesModel()
        {
            try
            {
                List<CategoryModel> categories = _db.Categories
                  .Where(x => x.IsEnabled == true && x.CreatedDate <= DateTime.Now && (x.ExpiredDate >= DateTime.Now || x.ExpiredDate == null))
                  .Select(x => new CategoryModel
                  {
                      CategoryID = x.CategoryID,
                      CategoryName = x.CategoryName,
                      SortOrder = x.SortOrder,
                  })
                  .OrderBy(x => x.SortOrder == null) 
                  .ThenBy(x => x.SortOrder).ToList();
                
                return categories;
            }
            catch (Exception ex)
            {
                //using (EventLog eventLog = new EventLog("Application"))
                //{
                //    eventLog.Source = "ShoppingApp";
                //    eventLog.WriteEntry(ex.ToString(), EventLogEntryType.Error);
                //}

                return null;
            }

        }

        public List<ProductModel> GetProductsByCategoryID(int categoryID)
        {
            try
            {
                List<ProductModel> products = _db.ProductCategories
                  .Where(x => x.Product.IsEnabled == true && x.Product.CreatedDate <= DateTime.Now && (x.Product.ExpiredDate >= DateTime.Now || x.Product.ExpiredDate == null) && x.CategoryID == categoryID)
                  .Select(x => new ProductModel
                  {
                      ProductID = x.ProductID,
                      ProductName = x.Product.ProductName,
                      SortOrder = x.Product.SortOrder,
                      CategoryID = categoryID
                  })
                  .OrderBy(x => x.SortOrder == null)
                  .ThenBy(x => x.SortOrder).ToList();
                 
                return products;
            }
            catch (Exception ex)
            {
                //using (EventLog eventLog = new EventLog("Application"))
                //{
                //    eventLog.Source = "ShoppingApp"; 
                //    eventLog.WriteEntry(ex.ToString(), EventLogEntryType.Error); 
                //}

                return null;
            }

        }
    }
}
