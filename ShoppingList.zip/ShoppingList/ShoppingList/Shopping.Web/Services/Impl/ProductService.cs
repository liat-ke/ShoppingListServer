﻿using Shopping.Data;
using Shopping.Data.Entities;
using Shopping.Models.SiteModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Shopping.Web.Services.Impl
{
    public class ProductService: BaseService, IProductService
    {
        private readonly IShoppingCartService _shoppingCartService;
        public ProductService(ShoppingContext db, IShoppingCartService shoppingCartService) : base(db)
        {
            _shoppingCartService = shoppingCartService;
        }
        public List<ShoppingCartModel> AddItemsToShoppingCart(ShoppingCartItemModel shoppingCartItems)
        {
            try
            {
                List<int> productIDsToAdd = shoppingCartItems.Products.Select(x => x.ProductID).ToList();
                List<int> exsistsSCProducts = _db.ShoppingCartItems.Where(x => x.CustomerID == shoppingCartItems.CustomerID).Select(x => x.ProductID).ToList();
                List<int> productsToUpdate = productIDsToAdd.Intersect(exsistsSCProducts).ToList();
                List<int> productsToAdd = productIDsToAdd.Except(exsistsSCProducts).ToList();
                int rowsEffected = 0;
                foreach (int productID in productsToUpdate)
                {
                    ShoppingCartItem item = _db.ShoppingCartItems.Where(x => x.CustomerID == shoppingCartItems.CustomerID && x.ProductID == productID).FirstOrDefault();
                    item.Quantity ++;
                    int numUpdated = _db.SaveChanges();
                    rowsEffected += numUpdated;
                }
                foreach (int productID in productsToAdd) {
                    _db.ShoppingCartItems.Add(new ShoppingCartItem
                    {
                        ProductID = productID,
                        CustomerID = shoppingCartItems.CustomerID,
                        CreatedDate = DateTime.Now,
                        Quantity = 1
                    });
                }
                int numAdded = _db.SaveChanges();
                rowsEffected += numAdded;
                if (rowsEffected == productIDsToAdd.Count) 
                {
                    List< ShoppingCartModel> allSCItems = _shoppingCartService.GetShoppingCartProducts(shoppingCartItems.CustomerID);
                    return allSCItems;
                } 
                else return null;
            }
            catch (Exception ex)
            {
                //using (EventLog eventLog = new EventLog("Application"))
                //{
                //    eventLog.Source = "ShoppingApp"; 
                //    eventLog.WriteEntry(ex.ToString(), EventLogEntryType.Error); 
                //}
                return null;
            }
        }
    }
}
