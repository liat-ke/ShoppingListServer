﻿using Json.Serialization;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Shopping.Data;
using Shopping.Data.SPEntities;
using Shopping.Models.SiteModels;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Shopping.Data.Entities;
using System;

namespace Shopping.Web.Services.Impl
{
    public class ShoppingCartService : BaseService, IShoppingCartService
    {
        public ShoppingCartService(ShoppingContext db) : base(db)
        {

        }

        public List<ShoppingCartModel> GetShoppingCartProducts(int customerID)
        {
            List<ShoppingCartModel> items = new List<ShoppingCartModel>();
            try
            {
                SqlParameter param1 = new SqlParameter("customerID", customerID);
                var dbSCDetails = _db.CustomerShoppingCartItems.FromSqlRaw("EXEC GetProductsOnShoppingCartByCustomerID @customerID", param1).ToList();
                if (dbSCDetails != null)
                {
                    items = dbSCDetails.Select(x => new ShoppingCartModel
                    {
                        CategoryID = x.CategoryID,
                        CategoryName = x.CategoryName,
                        CountCategory = x.CountCategory,
                        InnerItems = Newtonsoft.Json.JsonConvert.DeserializeObject<List<InnerItem>>(x.ProductsJson)
                    }).ToList();
                }
                return items;
            }
            catch (Exception ex)
            {
                //using (EventLog eventLog = new EventLog("Application"))
                //{
                //    eventLog.Source = "ShoppingApp"; 
                //    eventLog.WriteEntry(ex.ToString(), EventLogEntryType.Error); 
                //}
                return items;
            }
        }

        public List<CustomerProductModel> AddItemToCustomerProducts(CustomerProductModel customerProduct)
        {
            List<CustomerProductModel> cutomerProducts = new List<CustomerProductModel>();
            try
            {
                CustomerProduct existsCustomerProduct = _db.CustomerProducts.Where(x => x.CustomerID == customerProduct.CustomerID
                && x.CategoryID == customerProduct.CategoryID
                && x.ProductName == customerProduct.ProductName).Select(x => x).FirstOrDefault();
                int rowsEffected = 0;

                if (existsCustomerProduct != null)
                {
                    existsCustomerProduct.Quantity ++;
                    int numUpdated = _db.SaveChanges();
                    rowsEffected += numUpdated;
                }
                else
                {
                    _db.CustomerProducts.Add(new CustomerProduct
                    {
                        CategoryID = customerProduct.CategoryID,
                        CustomerID = customerProduct.CustomerID,
                        ProductName = customerProduct.ProductName,
                        CreatedDate = DateTime.Now,
                        Quantity = 1
                    });
                }
                int numAdded = _db.SaveChanges();
                rowsEffected += numAdded;

                if (rowsEffected == 1)
                {
                    List<CustomerProductModel> allCustomerProducts = GetAllCustomerProducts(customerProduct.CustomerID);
                    return allCustomerProducts;
                }
                else return null;
            }
            catch (Exception ex)
            {
                //using (EventLog eventLog = new EventLog("Application"))
                //{
                //    eventLog.Source = "ShoppingApp"; 
                //    eventLog.WriteEntry(ex.ToString(), EventLogEntryType.Error); 
                //}
                return cutomerProducts;
            }
        }

        private List<CustomerProductModel> GetAllCustomerProducts(int customerID)
        {

            List<CustomerProductModel> items = new List<CustomerProductModel>();
            try
            {
                SqlParameter param1 = new SqlParameter("customerID", customerID);
                var dbSCDetails = _db.CustomerProductsAdded.FromSqlRaw("EXEC GetCustomerProducts @customerID", param1).ToList();
                if (dbSCDetails != null)
                {
                    items = dbSCDetails.Select(x => new CustomerProductModel
                    {
                        CategoryID = x.CategoryID,
                        CategoryName = x.CategoryName,
                        CountCategory = x.CountCategory,
                        InnerCustomerItems = Newtonsoft.Json.JsonConvert.DeserializeObject<List<InnerCustomerItem>>(x.ProductsJson)
                    }).ToList();
                }
                return items;
            }
            catch (Exception ex)
            {
                //using (EventLog eventLog = new EventLog("Application"))
                //{
                //    eventLog.Source = "ShoppingApp"; 
                //    eventLog.WriteEntry(ex.ToString(), EventLogEntryType.Error); 
                //}
                return items;
            }
        }
    }
}
