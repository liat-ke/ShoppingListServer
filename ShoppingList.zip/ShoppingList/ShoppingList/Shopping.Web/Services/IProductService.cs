﻿using Shopping.Data.Entities;
using Shopping.Models.SiteModels;
using System.Collections.Generic;

namespace Shopping.Web.Services
{
    public interface IProductService
    {
        List<ShoppingCartModel> AddItemsToShoppingCart(ShoppingCartItemModel shoppingCartItems);
    }
}
