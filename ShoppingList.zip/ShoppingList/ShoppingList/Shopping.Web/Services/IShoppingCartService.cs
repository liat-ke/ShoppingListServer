﻿using Shopping.Data.Entities;
using Shopping.Models.SiteModels;
using System.Collections.Generic;

namespace Shopping.Web.Services
{
    public interface IShoppingCartService
    {
       List<ShoppingCartModel> GetShoppingCartProducts(int customerID);
       List<CustomerProductModel> AddItemToCustomerProducts(CustomerProductModel customerProduct);
    }
}
