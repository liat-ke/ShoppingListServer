﻿using Shopping.Models.SiteModels;
using System.Collections.Generic;

namespace Shopping.Web.Services
{
    public interface ICategoryService
    {
        #region Getter
        List<CategoryModel> GetEnabledCategoriesModel();
        List<ProductModel> GetProductsByCategoryID(int categoryID);
        #endregion
    }
}
