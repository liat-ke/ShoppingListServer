﻿using Microsoft.Extensions.DependencyInjection;
using Shopping.Web.Services;
using Shopping.Web.Services.Impl;

namespace Shopping.Web.Configuration
{
    public static class ServicesConfiguration
    {
        public static void ShoppingServices(this IServiceCollection services)
        {
            services.AddScoped<ICategoryService, CategoryService>();
            services.AddTransient<ICategoryService, CategoryService>();
            services.AddScoped<IProductService, ProductService>();
            services.AddTransient<IProductService, ProductService>();
            services.AddScoped<IShoppingCartService, ShoppingCartService>();
            services.AddTransient<IShoppingCartService, ShoppingCartService>();
        }
    }
}
