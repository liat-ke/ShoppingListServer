﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.Data.SPEntities
{
    public class ShoppingCartItems
    {
        [Key]
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public int CountCategory { get; set; }
        public string ProductsJson { get; set; }
    }

}
