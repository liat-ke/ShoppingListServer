﻿using Shopping.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Shopping.Data.SPEntities;

namespace Shopping.Data
{
    public class ShoppingContext : DbContext
    {
        public ShoppingContext(DbContextOptions<ShoppingContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProductCategory>()
               .HasKey(x => new { x.ProductID, x.CategoryID });

            modelBuilder.Entity<ProductCategory>()
          .HasOne(pc => pc.Product)
          .WithMany(p => p.ProductCategories)
          .HasForeignKey(pc => pc.ProductID);

            modelBuilder.Entity<ProductCategory>()
                .HasOne(pc => pc.Category)
                .WithMany(c => c.ProductCategories)
                .HasForeignKey(pc => pc.CategoryID);

            base.OnModelCreating(modelBuilder);
        }

        #region Entities
        public DbSet<Category> Categories { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductCategory> ProductCategories { get; set; }
        public DbSet<ShoppingCartItem> ShoppingCartItems { get; set; }
        public DbSet<CustomerProduct> CustomerProducts { get; set; }
        #endregion

        #region SP Entities
        public DbSet<ShoppingCartItems> CustomerShoppingCartItems { get; set; }
        public DbSet<CustomerProductsAdded> CustomerProductsAdded { get; set; }
        #endregion
    }
}
